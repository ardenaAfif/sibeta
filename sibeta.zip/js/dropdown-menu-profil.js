let subMenu = document.getElementById("profil-img");

function toogleMenu() {
    subMenu.classList.toggle("open-menu");
}